package Model;

public enum HairColor {
    BLACK,
    BLUE,
    YELLOW,
    BROWN;
}
