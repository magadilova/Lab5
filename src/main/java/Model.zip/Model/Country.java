package Model;

public enum Country {
    FRANCE,
    INDIA,
    ITALY;
}
