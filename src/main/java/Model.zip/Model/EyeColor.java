package Model;

public enum EyeColor {
    GREEN,
    BLUE,
    WHITE,
    BROWN;
}
