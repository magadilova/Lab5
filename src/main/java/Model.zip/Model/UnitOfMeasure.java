package Model;

public enum UnitOfMeasure {
    CENTIMETERS,
    MILLILITERS,
    MILLIGRAMS;

}
